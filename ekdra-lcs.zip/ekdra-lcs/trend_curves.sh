flareout="temp.out"
energyout="energies_ekdra.out"
arrivalout="interarrival_times_ekdra.out"

for f in ./*/*/*/*
do
    dir="${f%/*}"
    python3 lightcurve_analysis.py "$f" 2.59 --plot > "$flareout"
    cp "$flareout" "$dir/lightcurve_data.out"
    python3 flare_energy.py "$flareout" "$f" >> "$energyout"
    python3 flare_interarrival.py "$flareout" >> "$arrivalout"
    rm "$flareout"
    echo "analyzing $dir"
done
