from astropy.io import fits
import argparse as ap
import numpy as np
from sklearn import svm
import matplotlib.pyplot as plt
from copy import *

def detrended_curve(time, flux):

    """    
    Fits a support vector machine to the curve (time, flux defined)
    with radial kernel functions; returns the trended curve.
    requires the line "from sklearn import svm"
    """
    
    meant = np.mean(time)
    stdt = np.std(time)
    meanf = np.mean(flux)
    stdf = np.std(flux)
    
    wt = [[(t-meant)/stdt] for t in time] # normalization for optimal SVM
    clf = svm.SVR(kernel='rbf',gamma='auto')
    clf.fit(wt,(flux-meanf)/stdf)
    flux_pred = clf.predict(wt)
    
    return flux_pred*stdf+meanf


def trend_lightcurve(time_raw,pdcflux_raw,windowsize,windowstep):
    
    """
    the trend of the lightcurve - up to 7 overlapping windows fit the curve with
    svm, take the median of them
    includes NaNs!
    """
    
    flux_raw = deepcopy(pdcflux_raw)
    
    n_votes = np.zeros(len(time_raw))
    lightcurve_trended = np.zeros(len(time_raw))
    
    for i in range(0,len(time_raw)-windowsize,windowstep):
        windowflux_raw = flux_raw[i:i+windowsize]
        windowtime_raw = time_raw[i:i+windowsize]
        has_errs = np.isnan(windowflux_raw)
        flux = windowflux_raw[~has_errs]
        time = windowtime_raw[~has_errs]
        flux_trend = detrended_curve(time,flux)
        
        windowflux_raw[~has_errs] = flux_trend
        lightcurve_trended[i:i+windowsize] = windowflux_raw
        n_votes[i:i+windowsize] += 1
     
    #for i in range(len(lightcurve_trended)):
    #    if not np.isnan(lightcurve_trended[i]):
    #        lightcurve_trended[i] /= float(n_votes[i])
    lightcurve_trended[np.where(lightcurve_trended == 0)[0]] = np.nan
     
    return lightcurve_trended

def lcplot(t,f,color=""):
    '''
    Simple lightcurve plot function
    '''
    plt.plot(t,f,color+".",alpha=0.1)
    plt.xlabel("Timestamp (days)")
    plt.ylabel(r"SAP flux ($e^-/s$)")

parser = ap.ArgumentParser( \
        description="Trend a lightcurve from a TESS FITS file")
parser.add_argument("inputfile",
        metavar="if",type=str,help="Input file")
parser.add_argument("period", type=float, help = "Period of the star")
parser.add_argument("--plot", help = "Plot the lightcurve", action="store_true")

args = parser.parse_args()

hdul = fits.open(args.inputfile)
lcdata = hdul[1].data
pdcflux_raw = lcdata.field(7)
time_raw = lcdata.field(0)

PERIOD=args.period
WINDOWPERIOD = 0.4
WINDOW_OVERLAP = 1
    
cadence = len(time_raw)/(time_raw[len(time_raw)-1] - time_raw[0])

windowsize = int(WINDOWPERIOD*PERIOD*cadence)
windowstep = int(windowsize/WINDOW_OVERLAP)

lc_trend = trend_lightcurve(time_raw,pdcflux_raw,windowsize,windowstep)

for i in range(len(time_raw)):
    print("{} {}".format(time_raw[i],lc_trend[i]))

if args.plot:
    plotname = args.inputfile[:-4]+"png"
    lcplot(time_raw,pdcflux_raw)
    plt.plot(time_raw,lc_trend)
    plt.legend(["PDC flux","Trend (SVM)"])
    plt.savefig(plotname)
